# OS-Project-1

The CPU scheduler is the part of the operating system that decides which process to execute next. It is a key component that has a significant impact on the overall system performance.
Programming a real CPU scheduler is a complex task. In this project, you have implemented a simplified simulator. The simulator will read a file containing a list of processes and simulate their execution according to different scheduling algorithms.
